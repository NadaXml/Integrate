﻿
namespace YooAsset.Editor
{
    public class EncryptionNone : IEncryptionServices
    {
        public EncryptResult Encrypt(EncryptFileInfo fileInfo)
        {
            throw new System.NotImplementedException();
        }
    }
}