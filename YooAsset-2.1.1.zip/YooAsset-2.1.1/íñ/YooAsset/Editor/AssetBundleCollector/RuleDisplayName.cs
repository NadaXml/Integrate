﻿
namespace YooAsset.Editor
{
    public class RuleDisplayName
    {
        public string ClassName;
        public string DisplayName;
    }
}