﻿
public class StreamingAssetsDefine
{
    /// <summary>
    /// 根目录名称（保持和YooAssets资源系统一致）
    /// </summary>
    public const string RootFolderName = "yoo";
}