# UniFramework.Machine

一个轻量级的状态机。
