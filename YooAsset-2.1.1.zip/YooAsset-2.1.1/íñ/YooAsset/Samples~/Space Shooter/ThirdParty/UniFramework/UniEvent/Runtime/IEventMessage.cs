﻿
namespace UniFramework.Event
{
	public interface IEventMessage
	{
	}
}