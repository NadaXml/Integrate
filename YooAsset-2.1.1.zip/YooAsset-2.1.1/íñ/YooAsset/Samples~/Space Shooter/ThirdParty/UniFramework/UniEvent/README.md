# UniFramework.Event

一个轻量级的事件系统。

