﻿
namespace YooAsset
{
    public enum EOperationStatus
    {
        None,
        Processing,
        Succeed,
        Failed
    }
}