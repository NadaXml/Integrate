**YooAsset**是一套用于Unity3D的资源管理系统，用于帮助研发团队快速部署和交付游戏。

它可以满足商业化游戏的各类需求，并且经历多款百万DAU游戏产品的验证。

更多信息请了解官方主页：https://github.com/tuyoogame/YooAsset

